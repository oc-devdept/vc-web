import React, { Component } from "react";
//Banner
import RedText from "Components/Layout/RedText";
class Test extends Component {
  render() {
    return <RedText>Heasdadsas!</RedText>
  }
}

export default Test;
