import React from "react";
// import TopPanel from "./TopPanel";
import TopHeader from "./TopHeader";
import MegaMenu from "./MegaMenu";

function NavBar(props) {
  return (
    <React.Fragment>
      {/* <TopPanel /> */}
      {/* <TopHeader /> */}
      <MegaMenu />
    </React.Fragment>
  );
}

export default NavBar;
