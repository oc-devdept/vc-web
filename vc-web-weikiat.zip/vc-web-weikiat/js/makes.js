export const makes = [ {"id":1, "make": "Toyota", "image": require("../images/toyota.png")}, 
  { "id":2, "make": "Honda", "image": require("../images/honda.png")},
  { "id":3, "make": "Suzuki", "image": require("../images/suzuki.png")}
];